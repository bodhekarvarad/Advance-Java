package supermarket;

public class Supermarket {

    public static void main(String[] args) {
        // TODO code application logic here
        
    }
}
